#include <gtk/gtk.h>


void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifid_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_male_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_female_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_handicap_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_confirmer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retourmodifacc_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retouramacc_clicked          (GtkButton       *button,
                                        gpointer         user_data);
