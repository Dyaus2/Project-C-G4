#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"


int s=0,h=0,mode=1;
char idd[20];

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
mode =2;
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* acc;
GtkWidget* window_mi;
acc = lookup_widget(objet, "window_acc");
gtk_widget_destroy(acc);
window_mi = create_window_modifierID();
gtk_widget_show(window_mi);

}


void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
mode =1;
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* acc;
GtkWidget* window_am;
acc = lookup_widget(objet, "window_acc");
gtk_widget_destroy(acc);
window_am = create_window_ajoutmodif();
gtk_widget_show(window_am);

}


void
on_button_modifid_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* window_actuel;
GtkWidget* window_am;
GtkWidget* input;
GtkWidget* output;

Etd e;
char id[20];

input = lookup_widget(objet, "entry_modifid");
output = lookup_widget(objet, "label_modifidres");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));

e = chercher(id, "etudiants.txt");

if(strcmp(e.id,"PNT")==0)
gtk_label_set_text(GTK_LABEL(output), "etudiant non existant");
else
{
strcpy(idd,e.id);
window_actuel = lookup_widget(objet, "window_modifierID");
gtk_widget_destroy(window_actuel);
window_am = create_window_ajoutmodif();
gtk_widget_show(window_am);

GtkWidget* ID;
GtkWidget* nom;
GtkWidget* prenom;
GtkWidget* classe;
GtkWidget* j;
GtkWidget* m;
GtkWidget* a;
GtkWidget* hn;
GtkWidget* sm;
GtkWidget* sf;



char clas[4][5]={"2P1","2P2","2P3","2P4"};
int i=0;

ID = lookup_widget(window_am, "entry_id");
nom = lookup_widget(window_am, "entry_nom");
prenom = lookup_widget(window_am, "entry_prenom");
classe = lookup_widget(window_am, "comboboxentry_class");
j = lookup_widget(window_am, "spinbutton_jour");
m = lookup_widget(window_am, "spinbutton_mois");
a = lookup_widget(window_am, "spinbutton_annee");
hn = lookup_widget(window_am, "checkbutton_handicap");
sm = lookup_widget(window_am, "radiobutton_male");
sf = lookup_widget(window_am, "radiobutton_female");


gtk_entry_set_text(GTK_ENTRY(ID),e.id);
gtk_entry_set_text(GTK_ENTRY(nom),e.nom);
gtk_entry_set_text(GTK_ENTRY(prenom),e.prenom);

while(i<4 && strcmp(clas[i],e.classe)!=0)
i++;
gtk_combo_box_set_active(GTK_COMBO_BOX(classe), i);

gtk_spin_button_set_value(j, e.dt_insc.Jour);
gtk_spin_button_set_value(m, e.dt_insc.Mois);
gtk_spin_button_set_value(a, e.dt_insc.Annee);

if(e.handi == 1)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hn), TRUE);
else
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hn), FALSE);

if(e.sexe == 1)
gtk_toggle_button_set_active(GTK_RADIO_BUTTON(sm), TRUE);
else
gtk_toggle_button_set_active(GTK_RADIO_BUTTON(sf), TRUE);
}
}


void
on_radiobutton_male_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
s=1;

}


void
on_radiobutton_female_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
s=0;
}


void
on_checkbutton_handicap_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
h=1;
}


void
on_button_confirmer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* window_ajoutmodif;
GtkWidget* ID;
GtkWidget* nom;
GtkWidget* prenom;
GtkWidget* classe;
GtkWidget* J;
GtkWidget* M;
GtkWidget* A;
GtkWidget* label_out;
//GtkWidget* output_label;
Etd d;



window_ajoutmodif = lookup_widget(objet, "window_ajoutmodif");

ID = lookup_widget(objet, "entry_id");
nom = lookup_widget(objet, "entry_nom");
prenom = lookup_widget(objet, "entry_prenom");
classe = lookup_widget(objet, "comboboxentry_class");
J = lookup_widget(objet, "spinbutton_jour");
M = lookup_widget(objet, "spinbutton_mois");
A = lookup_widget(objet, "spinbutton_annee");
//output_label = lookup_widget(objet, "label_GSDonResultatAM");
label_out = lookup_widget(objet, "label_ajoutmodifconfirm");

strcpy(d.id,gtk_entry_get_text(GTK_ENTRY(ID)));
strcpy(d.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(d.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(d.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));
d.dt_insc.Jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(J));
d.dt_insc.Mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(M));
d.dt_insc.Annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(A));
d.handi = h;
d.sexe = s;

if(mode == 1)
{
ajouter(d, "etudiants.txt");
gtk_label_set_text(GTK_LABEL(label_out), "Ajoutee ");
}
if(mode == 2)
{
modifier(idd, d, "etudiants.txt");
gtk_label_set_text(GTK_LABEL(label_out), "Modifiee ");
}
}


void
on_button_retourmodifacc_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* window_modif;
GtkWidget* window_acc;

window_modif = lookup_widget(objet,"window_modifierID");
gtk_widget_destroy(window_modif);
window_acc = create_window_acc();
gtk_widget_show(window_acc);
}


void
on_button_retouramacc_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget* objet = GTK_WIDGET(button);
GtkWidget* window_modif;
GtkWidget* window_acc;

window_modif = lookup_widget(objet,"window_ajoutmodif");
gtk_widget_destroy(window_modif);
window_acc = create_window_acc();
gtk_widget_show(window_acc);
}

