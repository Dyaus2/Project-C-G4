#include <gtk/gtk.h>

typedef struct
{
    int Jour,Mois,Annee;
}Date;
typedef struct
{
    char id[20];
    char nom[20];
    char prenom[20];
    char classe[10];
    Date dt_insc;
    int handi,sexe;
}Etd;

int ajouter(Etd d, char filename []);
int modifier(char id[], Etd nouv, char * filename);
Etd chercher(char id[], char * filename);
