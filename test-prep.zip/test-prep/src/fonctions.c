#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonctions.h"

//ajout d'un don 

int ajouter(Etd d , char filename [])
{
    FILE * f=fopen(filename, "a");
    if(f!=NULL)
    {
        fprintf(f,"%s %s %s %s %d/%d/%d %d %d ]\n",d.id,d.nom,d.prenom,d.classe,d.dt_insc.Jour,d.dt_insc.Mois,d.dt_insc.Annee,d.handi,d.sexe);
        fclose(f);
        return 1;
    }
    else return 0;
}
// modification d'un don
int modifier(char id[], Etd nouv, char * filename)
{
Etd d;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %s %s %s %d/%d/%d %d %d ]\n",d.id,d.nom,d.prenom,d.classe,&d.dt_insc.Jour,&d.dt_insc.Mois,&d.dt_insc.Annee,&d.handi,&d.sexe)!=EOF)
{
if(strcmp(d.id,id) != 0)
        fprintf(f2,"%s %s %s %s %d/%d/%d %d %d ]\n",d.id,d.nom,d.prenom,d.classe,d.dt_insc.Jour,d.dt_insc.Mois,d.dt_insc.Annee,d.handi,d.sexe);
else

  fprintf(f2,"%s %s %s %s %d/%d/%d %d %d ]\n",nouv.id,nouv.nom,nouv.prenom,nouv.classe,nouv.dt_insc.Jour,nouv.dt_insc.Mois,nouv.dt_insc.Annee,nouv.handi,nouv.sexe);

}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
        return 1;
    }
  
}
// chercher un don
Etd chercher(char id[], char * filename)
{
Etd d,d1; int tr=0;
    FILE * f=fopen(filename, "r");
 if(f!=NULL )
    {
while(fscanf(f,"%s %s %s %s %d/%d/%d %d %d ]\n",d.id,d.nom,d.prenom,d.classe,&d.dt_insc.Jour,&d.dt_insc.Mois,&d.dt_insc.Annee,&d.handi,&d.sexe)!=EOF && tr==0)
{if(strcmp(d.id,id) == 0)
tr=1;
d1 = d;
}
}
if(tr==0)
strcpy(d1.id,"PNT");;
return d1;

}
